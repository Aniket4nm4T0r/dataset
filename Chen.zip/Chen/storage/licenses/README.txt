This directory is used to store license keys, however we do not ship with a license key file for obvious reasons

As you add 3rd parties components to your bot, add the license keys to a file license.keys in this directory, the format is


LICENSE_KEY_NAME = license key data
