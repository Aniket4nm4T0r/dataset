#! /bin/sh

clear

curl "http://127.0.0.1:8989/api/rest/v1.0/ask?userid=testuser1&question=Hello"

